import boto3
import os
import base64
import json

redshift_data = boto3.client('redshift-data')

WorkgroupName = os.environ['REDSHIFT_WORKGROUP']
database = os.environ['REDSHIFT_DATABASE']
SecretArn = os.environ['REDSHIFT_SECRET_ARN']

def lambda_handler(event, context):
    
    for topic_pa, records in event['records'].items():
        for record in records:

            decoded_value = json.loads(base64.b64decode(record['value']).decode('utf-8'))

    
            employee_id = decoded_value.get('employee_id')
            employee_name = decoded_value.get('employee_name')
            employee_age = decoded_value.get('employee_age')


            # Try to update the row
            update_statement = f"""
                UPDATE employees
                SET employee_name = '{employee_name}', employee_age = '{employee_age}'
                WHERE employee_id = '{employee_id}';
            """

            # If the row doesn't exist, insert it
            insert_statement = f"""
                INSERT INTO employees (employee_id, employee_name, employee_age)
                SELECT '{employee_id}', '{employee_name}', '{employee_age}'
                WHERE NOT EXISTS (SELECT 1 FROM employees WHERE employee_id = '{employee_id}');
            """
        
            try:
        
                # Execute the update statement
                redshift_data.execute_statement(
                    WorkgroupName=WorkgroupName,
                    Database=database,
                    SecretArn=SecretArn,
                    Sql=update_statement
                )
        
                # Execute the insert statement
                redshift_data.execute_statement(
                    WorkgroupName=WorkgroupName,
                    Database=database,
                    SecretArn=SecretArn,
                    Sql=insert_statement
                )
            except Exception as e:
                print('Error performing upsert operation:', e)
                return {
                    'statusCode': 500,
                    'body': 'Error performing upsert operation.'
                }
        
    return {'statusCode': 200,'body': 'Upsert operation successful!'}
